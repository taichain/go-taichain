This is a port of [gota](https://github.com/phemmer/gota) to be adapted inside of InfluxDB.

This port was made with the permission of the author, Patrick Hemmer, and has been modified to remove dependencies that are not part of InfluxDB.
